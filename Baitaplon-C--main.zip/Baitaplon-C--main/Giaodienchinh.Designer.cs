﻿namespace Baitaplon
{
    partial class Giaodienchinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2AnimateWindow1 = new Guna.UI2.WinForms.Guna2AnimateWindow(this.components);
            this.guna2AnimateWindow2 = new Guna.UI2.WinForms.Guna2AnimateWindow(this.components);
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Panel_Profile_Container = new Guna.UI2.WinForms.Guna2Panel();
            this.sidebarPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.pnlCoSoContainer = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button10 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button9 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.btnQuanLyCoSo = new Guna.UI2.WinForms.Guna2Button();
            this.pnlKhachContainer = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button12 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button11 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.btnQuanLyKhach = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.pnlBaoCaoContainer = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button14 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button13 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.btnBaoCao = new Guna.UI2.WinForms.Guna2Button();
            this.pnlCaiDatContainer = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.btnCaiDat = new Guna.UI2.WinForms.Guna2Button();
            this.MenuTransition = new System.Windows.Forms.Timer(this.components);
            this.KhachTransition = new System.Windows.Forms.Timer(this.components);
            this.BaoCaoTransition = new System.Windows.Forms.Timer(this.components);
            this.CaiDatTransition = new System.Windows.Forms.Timer(this.components);
            this.pnlHeader = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.lblTenNguoiDung = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txtTimkiem = new Guna.UI2.WinForms.Guna2TextBox();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.notifyIcon2 = new System.Windows.Forms.NotifyIcon(this.components);
            this.flowLayoutPanel1.SuspendLayout();
            this.Panel_Profile_Container.SuspendLayout();
            this.sidebarPanel.SuspendLayout();
            this.pnlCoSoContainer.SuspendLayout();
            this.pnlKhachContainer.SuspendLayout();
            this.pnlBaoCaoContainer.SuspendLayout();
            this.pnlCaiDatContainer.SuspendLayout();
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.flowLayoutPanel1.Controls.Add(this.sidebarPanel);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(429, 625);
            this.flowLayoutPanel1.TabIndex = 1;
            this.flowLayoutPanel1.WrapContents = false;
            // 
            // Panel_Profile_Container
            // 
            this.Panel_Profile_Container.Controls.Add(this.flowLayoutPanel1);
            this.Panel_Profile_Container.Dock = System.Windows.Forms.DockStyle.Left;
            this.Panel_Profile_Container.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(45)))), ((int)(((byte)(80)))));
            this.Panel_Profile_Container.Location = new System.Drawing.Point(0, 127);
            this.Panel_Profile_Container.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Panel_Profile_Container.Name = "Panel_Profile_Container";
            this.Panel_Profile_Container.Size = new System.Drawing.Size(429, 625);
            this.Panel_Profile_Container.TabIndex = 2;
            // 
            // sidebarPanel
            // 
            this.sidebarPanel.AutoScroll = true;
            this.sidebarPanel.Controls.Add(this.guna2Button1);
            this.sidebarPanel.Controls.Add(this.pnlCoSoContainer);
            this.sidebarPanel.Controls.Add(this.pnlKhachContainer);
            this.sidebarPanel.Controls.Add(this.guna2Button6);
            this.sidebarPanel.Controls.Add(this.pnlBaoCaoContainer);
            this.sidebarPanel.Controls.Add(this.pnlCaiDatContainer);
            this.sidebarPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.sidebarPanel.Location = new System.Drawing.Point(4, 4);
            this.sidebarPanel.Margin = new System.Windows.Forms.Padding(4);
            this.sidebarPanel.Name = "sidebarPanel";
            this.sidebarPanel.Size = new System.Drawing.Size(425, 732);
            this.sidebarPanel.TabIndex = 7;
            this.sidebarPanel.WrapContents = false;
            // 
            // guna2Button1
            // 
            this.guna2Button1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button1.BorderRadius = 20;
            this.guna2Button1.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Image = global::Baitaplon.Properties.Resources.house;
            this.guna2Button1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button1.Location = new System.Drawing.Point(3, 2);
            this.guna2Button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button1.ShadowDecoration.Depth = 15;
            this.guna2Button1.Size = new System.Drawing.Size(397, 46);
            this.guna2Button1.TabIndex = 0;
            this.guna2Button1.Text = "Trang chủ";
            // 
            // pnlCoSoContainer
            // 
            this.pnlCoSoContainer.Controls.Add(this.guna2Button10);
            this.pnlCoSoContainer.Controls.Add(this.guna2Button9);
            this.pnlCoSoContainer.Controls.Add(this.guna2Button8);
            this.pnlCoSoContainer.Controls.Add(this.guna2Button4);
            this.pnlCoSoContainer.Controls.Add(this.btnQuanLyCoSo);
            this.pnlCoSoContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCoSoContainer.Location = new System.Drawing.Point(3, 52);
            this.pnlCoSoContainer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlCoSoContainer.Name = "pnlCoSoContainer";
            this.pnlCoSoContainer.Size = new System.Drawing.Size(397, 55);
            this.pnlCoSoContainer.TabIndex = 2;
            // 
            // guna2Button10
            // 
            this.guna2Button10.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button10.BorderRadius = 20;
            this.guna2Button10.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button10.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button10.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.guna2Button10.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button10.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button10.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button10.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Button10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button10.ForeColor = System.Drawing.Color.White;
            this.guna2Button10.Image = global::Baitaplon.Properties.Resources.interior_design;
            this.guna2Button10.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button10.Location = new System.Drawing.Point(0, 202);
            this.guna2Button10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button10.Name = "guna2Button10";
            this.guna2Button10.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button10.ShadowDecoration.Depth = 15;
            this.guna2Button10.Size = new System.Drawing.Size(397, 49);
            this.guna2Button10.TabIndex = 7;
            this.guna2Button10.Text = "Quản lý tài sản";
            // 
            // guna2Button9
            // 
            this.guna2Button9.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button9.BorderRadius = 20;
            this.guna2Button9.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button9.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.guna2Button9.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button9.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button9.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button9.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button9.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Button9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button9.ForeColor = System.Drawing.Color.White;
            this.guna2Button9.Image = global::Baitaplon.Properties.Resources.pricing;
            this.guna2Button9.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button9.Location = new System.Drawing.Point(0, 153);
            this.guna2Button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button9.Name = "guna2Button9";
            this.guna2Button9.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button9.ShadowDecoration.Depth = 15;
            this.guna2Button9.Size = new System.Drawing.Size(397, 49);
            this.guna2Button9.TabIndex = 6;
            this.guna2Button9.Text = "Cấu hình đơn giá, danh mục dịch vụ";
            // 
            // guna2Button8
            // 
            this.guna2Button8.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button8.BorderRadius = 20;
            this.guna2Button8.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button8.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button8.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.guna2Button8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button8.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Button8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button8.ForeColor = System.Drawing.Color.White;
            this.guna2Button8.Image = global::Baitaplon.Properties.Resources.room;
            this.guna2Button8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button8.Location = new System.Drawing.Point(0, 104);
            this.guna2Button8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button8.ShadowDecoration.Depth = 15;
            this.guna2Button8.Size = new System.Drawing.Size(397, 49);
            this.guna2Button8.TabIndex = 5;
            this.guna2Button8.Text = "Loại phòng";
            // 
            // guna2Button4
            // 
            this.guna2Button4.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(45)))), ((int)(((byte)(80)))));
            this.guna2Button4.BorderRadius = 20;
            this.guna2Button4.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button4.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.guna2Button4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button4.ForeColor = System.Drawing.Color.White;
            this.guna2Button4.Image = global::Baitaplon.Properties.Resources.bedroom;
            this.guna2Button4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button4.Location = new System.Drawing.Point(0, 55);
            this.guna2Button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button4.ShadowDecoration.Depth = 15;
            this.guna2Button4.Size = new System.Drawing.Size(397, 49);
            this.guna2Button4.TabIndex = 4;
            this.guna2Button4.Text = "Danh sách phòng";
            // 
            // btnQuanLyCoSo
            // 
            this.btnQuanLyCoSo.BackColor = System.Drawing.Color.Transparent;
            this.btnQuanLyCoSo.BorderRadius = 20;
            this.btnQuanLyCoSo.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnQuanLyCoSo.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnQuanLyCoSo.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnQuanLyCoSo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnQuanLyCoSo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnQuanLyCoSo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnQuanLyCoSo.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.btnQuanLyCoSo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnQuanLyCoSo.ForeColor = System.Drawing.Color.White;
            this.btnQuanLyCoSo.Image = global::Baitaplon.Properties.Resources.list;
            this.btnQuanLyCoSo.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnQuanLyCoSo.Location = new System.Drawing.Point(0, 0);
            this.btnQuanLyCoSo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnQuanLyCoSo.Name = "btnQuanLyCoSo";
            this.btnQuanLyCoSo.ShadowDecoration.Color = System.Drawing.Color.White;
            this.btnQuanLyCoSo.ShadowDecoration.Depth = 15;
            this.btnQuanLyCoSo.Size = new System.Drawing.Size(397, 55);
            this.btnQuanLyCoSo.TabIndex = 1;
            this.btnQuanLyCoSo.Text = "Quản lý TT cơ sở";
            this.btnQuanLyCoSo.Click += new System.EventHandler(this.btnQuanLyCoSo_Click);
            // 
            // pnlKhachContainer
            // 
            this.pnlKhachContainer.Controls.Add(this.guna2Button12);
            this.pnlKhachContainer.Controls.Add(this.guna2Button11);
            this.pnlKhachContainer.Controls.Add(this.guna2Button2);
            this.pnlKhachContainer.Controls.Add(this.btnQuanLyKhach);
            this.pnlKhachContainer.Location = new System.Drawing.Point(4, 113);
            this.pnlKhachContainer.Margin = new System.Windows.Forms.Padding(4);
            this.pnlKhachContainer.Name = "pnlKhachContainer";
            this.pnlKhachContainer.Size = new System.Drawing.Size(391, 55);
            this.pnlKhachContainer.TabIndex = 7;
            // 
            // guna2Button12
            // 
            this.guna2Button12.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button12.BorderRadius = 20;
            this.guna2Button12.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button12.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button12.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.guna2Button12.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button12.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button12.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button12.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button12.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Button12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button12.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button12.ForeColor = System.Drawing.Color.White;
            this.guna2Button12.Image = global::Baitaplon.Properties.Resources.clock;
            this.guna2Button12.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button12.Location = new System.Drawing.Point(0, 153);
            this.guna2Button12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button12.Name = "guna2Button12";
            this.guna2Button12.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button12.ShadowDecoration.Depth = 15;
            this.guna2Button12.Size = new System.Drawing.Size(391, 49);
            this.guna2Button12.TabIndex = 5;
            this.guna2Button12.Text = "Lịch sử thuê phòng";
            // 
            // guna2Button11
            // 
            this.guna2Button11.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button11.BorderRadius = 20;
            this.guna2Button11.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button11.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button11.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.guna2Button11.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button11.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button11.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button11.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Button11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button11.ForeColor = System.Drawing.Color.White;
            this.guna2Button11.Image = global::Baitaplon.Properties.Resources.contract;
            this.guna2Button11.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button11.Location = new System.Drawing.Point(0, 104);
            this.guna2Button11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button11.Name = "guna2Button11";
            this.guna2Button11.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button11.ShadowDecoration.Depth = 15;
            this.guna2Button11.Size = new System.Drawing.Size(391, 49);
            this.guna2Button11.TabIndex = 4;
            this.guna2Button11.Text = "Hợp đồng";
            // 
            // guna2Button2
            // 
            this.guna2Button2.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button2.BorderRadius = 20;
            this.guna2Button2.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button2.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.Image = global::Baitaplon.Properties.Resources.ancestors;
            this.guna2Button2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button2.Location = new System.Drawing.Point(0, 55);
            this.guna2Button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button2.ShadowDecoration.Depth = 15;
            this.guna2Button2.Size = new System.Drawing.Size(391, 49);
            this.guna2Button2.TabIndex = 3;
            this.guna2Button2.Text = "Khách thuê";
            // 
            // btnQuanLyKhach
            // 
            this.btnQuanLyKhach.BackColor = System.Drawing.Color.Transparent;
            this.btnQuanLyKhach.BorderRadius = 20;
            this.btnQuanLyKhach.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnQuanLyKhach.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnQuanLyKhach.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnQuanLyKhach.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnQuanLyKhach.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnQuanLyKhach.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnQuanLyKhach.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.btnQuanLyKhach.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnQuanLyKhach.ForeColor = System.Drawing.Color.White;
            this.btnQuanLyKhach.Image = global::Baitaplon.Properties.Resources.team;
            this.btnQuanLyKhach.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnQuanLyKhach.Location = new System.Drawing.Point(0, 0);
            this.btnQuanLyKhach.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnQuanLyKhach.Name = "btnQuanLyKhach";
            this.btnQuanLyKhach.ShadowDecoration.Color = System.Drawing.Color.White;
            this.btnQuanLyKhach.ShadowDecoration.Depth = 15;
            this.btnQuanLyKhach.Size = new System.Drawing.Size(391, 55);
            this.btnQuanLyKhach.TabIndex = 2;
            this.btnQuanLyKhach.Text = "Quản lý khách và Hợp đồng";
            this.btnQuanLyKhach.Click += new System.EventHandler(this.btnQuanLyKhach_Click);
            // 
            // guna2Button6
            // 
            this.guna2Button6.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button6.BorderRadius = 20;
            this.guna2Button6.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button6.ForeColor = System.Drawing.Color.White;
            this.guna2Button6.Image = global::Baitaplon.Properties.Resources.bill;
            this.guna2Button6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button6.Location = new System.Drawing.Point(3, 174);
            this.guna2Button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button6.ShadowDecoration.Depth = 15;
            this.guna2Button6.Size = new System.Drawing.Size(392, 55);
            this.guna2Button6.TabIndex = 3;
            this.guna2Button6.Text = "Quản lý hóa đơn";
            // 
            // pnlBaoCaoContainer
            // 
            this.pnlBaoCaoContainer.Controls.Add(this.guna2Button14);
            this.pnlBaoCaoContainer.Controls.Add(this.guna2Button13);
            this.pnlBaoCaoContainer.Controls.Add(this.guna2Button3);
            this.pnlBaoCaoContainer.Controls.Add(this.btnBaoCao);
            this.pnlBaoCaoContainer.Location = new System.Drawing.Point(4, 235);
            this.pnlBaoCaoContainer.Margin = new System.Windows.Forms.Padding(4);
            this.pnlBaoCaoContainer.Name = "pnlBaoCaoContainer";
            this.pnlBaoCaoContainer.Size = new System.Drawing.Size(395, 55);
            this.pnlBaoCaoContainer.TabIndex = 0;
            // 
            // guna2Button14
            // 
            this.guna2Button14.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button14.BorderRadius = 20;
            this.guna2Button14.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button14.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button14.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.guna2Button14.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button14.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button14.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button14.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button14.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Button14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button14.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button14.ForeColor = System.Drawing.Color.White;
            this.guna2Button14.Image = global::Baitaplon.Properties.Resources.bill__2_;
            this.guna2Button14.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button14.Location = new System.Drawing.Point(0, 153);
            this.guna2Button14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button14.Name = "guna2Button14";
            this.guna2Button14.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button14.ShadowDecoration.Depth = 15;
            this.guna2Button14.Size = new System.Drawing.Size(395, 49);
            this.guna2Button14.TabIndex = 7;
            this.guna2Button14.Text = "Lịch sử thanh toán";
            // 
            // guna2Button13
            // 
            this.guna2Button13.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button13.BorderRadius = 20;
            this.guna2Button13.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button13.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button13.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.guna2Button13.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button13.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button13.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button13.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button13.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Button13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button13.ForeColor = System.Drawing.Color.White;
            this.guna2Button13.Image = global::Baitaplon.Properties.Resources.analysing;
            this.guna2Button13.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button13.Location = new System.Drawing.Point(0, 104);
            this.guna2Button13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button13.Name = "guna2Button13";
            this.guna2Button13.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button13.ShadowDecoration.Depth = 15;
            this.guna2Button13.Size = new System.Drawing.Size(395, 49);
            this.guna2Button13.TabIndex = 6;
            this.guna2Button13.Text = "Báo cáo thống kê";
            // 
            // guna2Button3
            // 
            this.guna2Button3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button3.BorderRadius = 20;
            this.guna2Button3.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button3.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.Image = global::Baitaplon.Properties.Resources.money;
            this.guna2Button3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button3.Location = new System.Drawing.Point(0, 55);
            this.guna2Button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button3.ShadowDecoration.Depth = 15;
            this.guna2Button3.Size = new System.Drawing.Size(395, 49);
            this.guna2Button3.TabIndex = 5;
            this.guna2Button3.Text = "Báo cáo doanh thu";
            // 
            // btnBaoCao
            // 
            this.btnBaoCao.BackColor = System.Drawing.Color.Transparent;
            this.btnBaoCao.BorderRadius = 20;
            this.btnBaoCao.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnBaoCao.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnBaoCao.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnBaoCao.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnBaoCao.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnBaoCao.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBaoCao.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.btnBaoCao.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnBaoCao.ForeColor = System.Drawing.Color.White;
            this.btnBaoCao.Image = global::Baitaplon.Properties.Resources.evaluation;
            this.btnBaoCao.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnBaoCao.Location = new System.Drawing.Point(0, 0);
            this.btnBaoCao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBaoCao.Name = "btnBaoCao";
            this.btnBaoCao.ShadowDecoration.Color = System.Drawing.Color.White;
            this.btnBaoCao.ShadowDecoration.Depth = 15;
            this.btnBaoCao.Size = new System.Drawing.Size(395, 55);
            this.btnBaoCao.TabIndex = 4;
            this.btnBaoCao.Text = "Báo cáo và hệ thống";
            this.btnBaoCao.Click += new System.EventHandler(this.btnBaoCao_Click);
            // 
            // pnlCaiDatContainer
            // 
            this.pnlCaiDatContainer.Controls.Add(this.guna2Button5);
            this.pnlCaiDatContainer.Controls.Add(this.btnCaiDat);
            this.pnlCaiDatContainer.Location = new System.Drawing.Point(4, 298);
            this.pnlCaiDatContainer.Margin = new System.Windows.Forms.Padding(4);
            this.pnlCaiDatContainer.Name = "pnlCaiDatContainer";
            this.pnlCaiDatContainer.Size = new System.Drawing.Size(395, 55);
            this.pnlCaiDatContainer.TabIndex = 0;
            // 
            // guna2Button5
            // 
            this.guna2Button5.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button5.BorderRadius = 20;
            this.guna2Button5.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(107)))), ((int)(((byte)(53)))));
            this.guna2Button5.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.guna2Button5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Button5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.guna2Button5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button5.ForeColor = System.Drawing.Color.White;
            this.guna2Button5.Image = global::Baitaplon.Properties.Resources.logout;
            this.guna2Button5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button5.Location = new System.Drawing.Point(0, 55);
            this.guna2Button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2Button5.ShadowDecoration.Depth = 15;
            this.guna2Button5.Size = new System.Drawing.Size(395, 49);
            this.guna2Button5.TabIndex = 7;
            this.guna2Button5.Text = "Đăng xuất";
            // 
            // btnCaiDat
            // 
            this.btnCaiDat.BackColor = System.Drawing.Color.Transparent;
            this.btnCaiDat.BorderRadius = 20;
            this.btnCaiDat.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnCaiDat.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnCaiDat.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnCaiDat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnCaiDat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnCaiDat.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCaiDat.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(89)))), ((int)(((byte)(132)))));
            this.btnCaiDat.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCaiDat.ForeColor = System.Drawing.Color.White;
            this.btnCaiDat.Image = global::Baitaplon.Properties.Resources.settings;
            this.btnCaiDat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnCaiDat.Location = new System.Drawing.Point(0, 0);
            this.btnCaiDat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCaiDat.Name = "btnCaiDat";
            this.btnCaiDat.ShadowDecoration.Color = System.Drawing.Color.White;
            this.btnCaiDat.ShadowDecoration.Depth = 15;
            this.btnCaiDat.Size = new System.Drawing.Size(395, 55);
            this.btnCaiDat.TabIndex = 6;
            this.btnCaiDat.Text = "Cài đặt";
            this.btnCaiDat.Click += new System.EventHandler(this.btnCaiDat_Click);
            // 
            // MenuTransition
            // 
            this.MenuTransition.Interval = 10;
            this.MenuTransition.Tick += new System.EventHandler(this.MenuTransition_Tick);
            // 
            // KhachTransition
            // 
            this.KhachTransition.Interval = 10;
            this.KhachTransition.Tick += new System.EventHandler(this.KhachTransition_Tick);
            // 
            // BaoCaoTransition
            // 
            this.BaoCaoTransition.Interval = 10;
            this.BaoCaoTransition.Tick += new System.EventHandler(this.BaoCaoTransition_Tick);
            // 
            // CaiDatTransition
            // 
            this.CaiDatTransition.Interval = 10;
            this.CaiDatTransition.Tick += new System.EventHandler(this.CaiDatTransition_Tick);
            // 
            // pnlHeader
            // 
            this.pnlHeader.Controls.Add(this.guna2HtmlLabel1);
            this.pnlHeader.Controls.Add(this.guna2PictureBox1);
            this.pnlHeader.Controls.Add(this.guna2CirclePictureBox1);
            this.pnlHeader.Controls.Add(this.lblTenNguoiDung);
            this.pnlHeader.Controls.Add(this.txtTimkiem);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(45)))), ((int)(((byte)(80)))));
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Margin = new System.Windows.Forms.Padding(4);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(1611, 127);
            this.pnlHeader.TabIndex = 2;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(162, 36);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(655, 70);
            this.guna2HtmlLabel1.TabIndex = 3;
            this.guna2HtmlLabel1.Text = "QUẢN LÝ PHÒNG TRỌ";
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = global::Baitaplon.Properties.Resources.security;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(12, 3);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(144, 103);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 4;
            this.guna2PictureBox1.TabStop = false;
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2CirclePictureBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2CirclePictureBox1.Image = global::Baitaplon.Properties.Resources.team1;
            this.guna2CirclePictureBox1.ImageRotate = 0F;
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(1270, 36);
            this.guna2CirclePictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(53, 49);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2CirclePictureBox1.TabIndex = 2;
            this.guna2CirclePictureBox1.TabStop = false;
            // 
            // lblTenNguoiDung
            // 
            this.lblTenNguoiDung.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTenNguoiDung.BackColor = System.Drawing.Color.Transparent;
            this.lblTenNguoiDung.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenNguoiDung.ForeColor = System.Drawing.Color.White;
            this.lblTenNguoiDung.Location = new System.Drawing.Point(1415, 46);
            this.lblTenNguoiDung.Margin = new System.Windows.Forms.Padding(4);
            this.lblTenNguoiDung.Name = "lblTenNguoiDung";
            this.lblTenNguoiDung.Size = new System.Drawing.Size(90, 30);
            this.lblTenNguoiDung.TabIndex = 1;
            this.lblTenNguoiDung.Text = "Xin chào,";
            // 
            // txtTimkiem
            // 
            this.txtTimkiem.BackColor = System.Drawing.Color.Transparent;
            this.txtTimkiem.BorderColor = System.Drawing.Color.Silver;
            this.txtTimkiem.BorderRadius = 20;
            this.txtTimkiem.BorderThickness = 0;
            this.txtTimkiem.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTimkiem.DefaultText = "";
            this.txtTimkiem.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTimkiem.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTimkiem.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTimkiem.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTimkiem.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTimkiem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTimkiem.ForeColor = System.Drawing.Color.DimGray;
            this.txtTimkiem.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTimkiem.IconLeft = global::Baitaplon.Properties.Resources.search;
            this.txtTimkiem.IconLeftOffset = new System.Drawing.Point(5, 0);
            this.txtTimkiem.Location = new System.Drawing.Point(837, 36);
            this.txtTimkiem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTimkiem.Name = "txtTimkiem";
            this.txtTimkiem.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txtTimkiem.PlaceholderText = "Tìm kiếm thông tin...";
            this.txtTimkiem.SelectedText = "";
            this.txtTimkiem.Size = new System.Drawing.Size(400, 49);
            this.txtTimkiem.TabIndex = 0;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // notifyIcon2
            // 
            this.notifyIcon2.Text = "notifyIcon2";
            this.notifyIcon2.Visible = true;
            // 
            // Giaodienchinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(234)))), ((int)(((byte)(248)))));
            this.ClientSize = new System.Drawing.Size(1611, 752);
            this.Controls.Add(this.Panel_Profile_Container);
            this.Controls.Add(this.pnlHeader);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Giaodienchinh";
            this.Load += new System.EventHandler(this.Giaodienchinh_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.Panel_Profile_Container.ResumeLayout(false);
            this.sidebarPanel.ResumeLayout(false);
            this.pnlCoSoContainer.ResumeLayout(false);
            this.pnlKhachContainer.ResumeLayout(false);
            this.pnlBaoCaoContainer.ResumeLayout(false);
            this.pnlCaiDatContainer.ResumeLayout(false);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow1;
        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Guna.UI2.WinForms.Guna2Panel Panel_Profile_Container;
        private System.Windows.Forms.Timer MenuTransition;
        private System.Windows.Forms.FlowLayoutPanel sidebarPanel;
        private Guna.UI2.WinForms.Guna2Panel pnlCoSoContainer;
        private Guna.UI2.WinForms.Guna2Button guna2Button10;
        private Guna.UI2.WinForms.Guna2Button guna2Button9;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button btnQuanLyCoSo;
        private Guna.UI2.WinForms.Guna2Button btnCaiDat;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button btnBaoCao;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button btnQuanLyKhach;
        private Guna.UI2.WinForms.Guna2Panel pnlKhachContainer;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private System.Windows.Forms.Timer KhachTransition;
        private Guna.UI2.WinForms.Guna2Button guna2Button12;
        private Guna.UI2.WinForms.Guna2Button guna2Button11;
        private Guna.UI2.WinForms.Guna2Panel pnlBaoCaoContainer;
        private Guna.UI2.WinForms.Guna2Button guna2Button14;
        private Guna.UI2.WinForms.Guna2Button guna2Button13;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private System.Windows.Forms.Timer BaoCaoTransition;
        private Guna.UI2.WinForms.Guna2Panel pnlCaiDatContainer;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private System.Windows.Forms.Timer CaiDatTransition;
        private Guna.UI2.WinForms.Guna2Panel pnlHeader;
        private Guna.UI2.WinForms.Guna2TextBox txtTimkiem;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblTenNguoiDung;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.NotifyIcon notifyIcon2;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
    }
}